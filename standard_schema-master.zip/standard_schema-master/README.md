# standard_schema
NAVER Map Data Standardization


네이버 데이터를 표준화 합니다.
